-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 10, 2023 at 06:17 PM
-- Server version: 8.0.32-0ubuntu0.20.04.2
-- PHP Version: 7.4.3-4ubuntu2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `CLMS`
--

-- --------------------------------------------------------

--
-- Table structure for table `assigned_users`
--

CREATE TABLE `assigned_users` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `assigned_userid` int DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `assigned_users`
--

INSERT INTO `assigned_users` (`id`, `user_id`, `project_id`, `assigned_userid`, `created_date`) VALUES
(1, 2, 1, 4, '2023-03-10 16:00:59'),
(2, 2, 1, 5, '2023-03-10 16:00:59'),
(3, 3, 2, 7, '2023-03-10 17:09:00');

-- --------------------------------------------------------

--
-- Table structure for table `owner_services`
--

CREATE TABLE `owner_services` (
  `id` int NOT NULL,
  `project_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `service_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `owner_services`
--

INSERT INTO `owner_services` (`id`, `project_id`, `user_id`, `service_id`) VALUES
(1, 1, NULL, 1),
(2, 1, NULL, 2),
(3, 1, NULL, 3),
(4, 1, NULL, 4),
(5, 1, NULL, 5),
(6, 1, NULL, 6),
(7, 1, NULL, 7),
(8, 2, NULL, 1),
(9, 2, NULL, 2),
(10, 2, NULL, 8),
(11, 3, NULL, 1),
(12, 3, NULL, 2),
(13, 3, NULL, 3),
(14, 3, NULL, 4),
(15, 3, NULL, 5),
(16, 4, NULL, 1),
(17, 4, NULL, 2),
(18, 4, NULL, 3),
(19, 4, NULL, 4),
(20, 4, NULL, 5),
(21, 4, NULL, 6),
(22, 4, NULL, 7),
(23, 4, NULL, 8),
(24, 4, NULL, 9),
(25, 4, NULL, 10);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `project_name` varchar(255) NOT NULL,
  `contractor` int DEFAULT NULL,
  `project_address1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `project_address2` varchar(250) DEFAULT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `pincode` int NOT NULL,
  `assigned_status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '0' COMMENT '0 is unassigned , 1 is assigned,2 is deleted',
  `accept_status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '0' COMMENT '0 is unaccepted , 1 is accepted,2 is deleted',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `user_id`, `project_name`, `contractor`, `project_address1`, `project_address2`, `state`, `city`, `pincode`, `assigned_status`, `accept_status`, `created_date`) VALUES
(1, 2, 'first_prject', 2, 'H No 123 ABC', 'rtuuuuuuuuuuuuuuyeueyt', 'Haryana', 'Panchkula', 123456, '0', '0', '2023-03-09 09:35:56'),
(2, 3, 'second project', 3, 'H No 123 ABC', 'rfergergregregre', 'Haryana', 'Panchkula', 123456, '1', '1', '2023-03-09 09:44:10'),
(3, 2, 'third-project', 2, 'H No 123 ABC', 'ewfergergtrgrte', 'Haryana', 'Panchkula', 123456, '0', '0', '2023-03-09 16:03:17'),
(4, 2, 'fourth project', 2, 'H No 123 ABC', 'wegfergergee', 'Haryana', 'Panchkula', 123456, '0', '0', '2023-03-10 09:46:07');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int NOT NULL,
  `service` varchar(250) NOT NULL,
  `service_status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service`, `service_status`, `created`) VALUES
(1, 'Plumbering', '1', '2023-03-09 04:03:14'),
(2, 'Roofing', '1', '2023-03-09 04:03:25'),
(3, 'HAVC', '1', '2023-03-09 04:03:34'),
(4, 'Painting', '1', '2023-03-09 04:03:42'),
(5, 'Sliding', '1', '2023-03-09 04:03:55'),
(6, 'Furnishing', '1', '2023-03-09 04:04:04'),
(7, 'Security System', '1', '2023-03-09 04:04:25'),
(8, 'Garage Doors & Openers', '1', '2023-03-09 04:04:58'),
(9, 'Plants', '1', '2023-03-09 04:05:16'),
(10, 'Drywall', '1', '2023-03-09 04:05:25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '0' COMMENT '0 is inactive ,1 is active, 2 is deleted',
  `user_type` enum('0','1','2','3') NOT NULL DEFAULT '0' COMMENT '0 is admin , 1 is owner,2gc,3sc',
  `token` varchar(255) DEFAULT NULL,
  `complete_status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `status`, `user_type`, `token`, `complete_status`, `created_at`) VALUES
(1, 'chandresh@yopmail.com', '$2y$10$sj8/BuQhk6PaeAJrb80M8eq35pv0BZfIikD/8EwGRiESe8RsROiHq', '1', '0', NULL, '1', '2023-03-09 09:21:56'),
(2, 'deepu123@yopmail.com', '$2y$10$hE02CFVeeTpNN.Mt4orrEekRrmJEquaBzfPKtvGn1QMKK5o7bzntS', '1', '1', NULL, '1', '2023-03-09 09:24:24'),
(3, 'bablu123@yopmail.com', '$2y$10$5wXojw5bQ5eCYngMLYKa7OM8/k0LNXG5xXQ5Cxg9PU2QQH3L1WFV6', '1', '1', NULL, '1', '2023-03-09 09:26:06'),
(4, 'ankush123@yopmail.com', '$2y$10$YXaa87JV5YbCsvJW06oi6.cgbUKPkuz1XXdyMEbHN8K28N9UOdxIa', '1', '2', NULL, '1', '2023-03-09 09:26:51'),
(5, 'abhishek123@yopmail.com', '$2y$10$xKItw5iaeG8jbqwG4RpTCuXB/vvRmsGyTzfHYTpG6DSdfuwfpsQay', '1', '2', NULL, '1', '2023-03-09 09:27:36'),
(6, 'harsh123@yopmail.com', '$2y$10$86UcB8ZW1S8I7FQyX8EUBukbqadlwknxVNKs2CnL.PDEp5G2ezCN2', '1', '2', NULL, '1', '2023-03-09 09:28:21'),
(7, 'prabhat123@yopmail.com', '$2y$10$rAKddpxGWKYcASlrrsNtWOGhLMypTknxDVzk0KTovEyCBqlZYxxWm', '1', '3', NULL, '1', '2023-03-09 09:29:11'),
(8, 'kajal123@yopmail.com', '$2y$10$gRf2/lfYWIPruSLOQYx0qOGvq3VGVQmIrLuyNNORJdufE1DAAb3yi', '1', '1', NULL, '1', '2023-03-09 15:50:28'),
(9, 'akshay123@yopmail.com', '$2y$10$9VrVjLe5EipttHj5QsJ9/eT.BwJM43/rkNqlvx3Q5/AV5Sq4Sbm2G', '1', '1', NULL, '0', '2023-03-10 14:02:17');

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE `user_profile` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `address1` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `address2` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `state` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `pincode` int DEFAULT NULL,
  `company_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`id`, `user_id`, `first_name`, `last_name`, `phone`, `address1`, `address2`, `state`, `city`, `pincode`, `company_name`) VALUES
(1, 1, 'Chandresh ', 'Yadav', '9559218299', 'Bauribojh Uttar Pradesh', 'Punchkula Haryana', 'Uttar Pradesh', 'Bhadohi', 221404, NULL),
(2, 2, 'Deepu', 'Gour', '0123456789', 'H No 123 ABC', 'gwjhfgewferjh', 'Haryana', 'Panchkula', 123456, NULL),
(3, 3, 'Bablu', 'Yadav', '01234567890', 'H No 123 ABC', 'jttyejytjytjtrj', 'Haryana', 'Panchkula', 123456, NULL),
(4, 4, 'Ankush', 'Singh', '01234567890', 'H No 123 ABC', 'feredgdgregergre', 'Haryana', 'Panchkula', 123456, 'Teq Mavens'),
(5, 5, 'Abhishek', 'Kumar', '1234567890', 'H No 123 ABC', 'dfggegreger', 'Haryana', 'Panchkula', 123456, 'Teq Mavens'),
(6, 6, 'Harsh', 'Kumar', '01234567890', 'H No 123 ABC', 'dgfhfhbgg', 'Haryana', 'Panchkula', 123456, 'Teq Mavens'),
(7, 7, 'Prabhat', 'Sharma', '01234567890', 'H No 123 ABC', 'dgrwtrheytr', 'Haryana', 'Panchkula', 123456, 'Teq Mavens'),
(8, 8, 'Kajal', 'Tyagi', '01234567890', 'H No 123 ABC', 'ytrh4yehyjy', 'Haryana', 'Panchkula', 123456, NULL),
(9, 9, 'Akshay', 'Jaggy', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_services`
--

CREATE TABLE `user_services` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `service_id` int NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_services`
--

INSERT INTO `user_services` (`id`, `user_id`, `service_id`, `created_date`) VALUES
(1, 4, 1, '2023-03-09 09:37:38'),
(2, 4, 3, '2023-03-09 09:37:38'),
(3, 4, 4, '2023-03-09 09:37:38'),
(4, 4, 6, '2023-03-09 09:37:38'),
(5, 4, 7, '2023-03-09 09:37:38'),
(6, 4, 9, '2023-03-09 09:37:38'),
(7, 5, 1, '2023-03-09 09:38:12'),
(8, 5, 2, '2023-03-09 09:38:12'),
(9, 5, 3, '2023-03-09 09:38:12'),
(10, 5, 4, '2023-03-09 09:38:12'),
(11, 5, 5, '2023-03-09 09:38:12'),
(12, 6, 1, '2023-03-09 09:38:42'),
(13, 6, 2, '2023-03-09 09:38:42'),
(14, 6, 3, '2023-03-09 09:38:42'),
(15, 6, 4, '2023-03-09 09:38:42'),
(16, 6, 5, '2023-03-09 09:38:42'),
(17, 7, 1, '2023-03-09 09:39:20'),
(18, 7, 2, '2023-03-09 09:39:20'),
(19, 7, 3, '2023-03-09 09:39:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assigned_users`
--
ALTER TABLE `assigned_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `owner_services`
--
ALTER TABLE `owner_services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_profile`
--
ALTER TABLE `user_profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_services`
--
ALTER TABLE `user_services`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assigned_users`
--
ALTER TABLE `assigned_users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `owner_services`
--
ALTER TABLE `owner_services`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_profile`
--
ALTER TABLE `user_profile`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_services`
--
ALTER TABLE `user_services`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
